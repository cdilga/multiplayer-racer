"""Numeric contracts, plus checks of the recorded camera presentations.
These do NOT assert that all UX/visibility tests passed; stress failures are reported.
"""
import json
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon
from camera_lab import W,H,PREF,FLOOR,Route,Car,RECT,area,power_cells,solve_weights,camera_fit,ahead

def run(root):
    root=Path(root);rng=np.random.default_rng(93017);report={'geometry':[],'replay':[]}
    for n in [1,2,5,16,32]:
        sites=rng.uniform([30,30],[W-30,H-30],(n,2))
        targets=rng.uniform(.5,2,n);targets/=targets.sum()
        weights,residual=solve_weights(sites,targets)
        cells=power_cells(sites,weights)
        aa=np.array([area(p) for p in cells])
        assert abs(aa.sum()-W*H)<.01
        assert min(aa)>0
        assert residual<1e-4
        overlap=sum(Polygon(cells[i]).intersection(Polygon(cells[j])).area for i in range(n) for j in range(i))
        assert overlap<.01
        report['geometry'].append({'sites':n,'partition_area_error_px2':abs(aa.sum()-W*H),'overlap_px2':overlap,'capacity_error_fraction':residual})
    vals=[ahead(v) for v in range(0,61)]
    assert all(b>=a for a,b in zip(vals,vals[1:]))
    route=Route([[0,0],[100,0],[100,100]],7)
    car=Car(0,route,90,12)
    assert car.future[-1,1]>0 and car.future[-1,0]==100
    points=np.vstack([car.body,car.corridor.reshape(-1,2)])
    fit=camera_fit(RECT,points,car.body)
    projected=points*fit['s']+fit['t']
    assert projected[:,0].min()>=11.9 and projected[:,0].max()<=W-11.9
    assert projected[:,1].min()>=11.9 and projected[:,1].max()<=H-11.9
    for path in sorted((root/'traces').glob('0[1-4]-*.json')):
        if path.name.endswith('-summary.json'):continue
        doc=json.loads(path.read_text());frames=doc['frames'];m=doc['metrics']
        assert all(f['min_car_px']>=18-.01 for f in frames)
        assert all(abs(sum(v['area'] for v in f['views'])-1)<1e-5 for f in frames)
        for e in m['events']:
            if e['type']!='merge_complete':continue
            f=min(frames,key=lambda f:abs(f['t']-e['t']))
            assert any(set(i+1 for i in e['cars']).issubset(v['players']) for v in f['views'])
        report['replay'].append({'scenario':m['scenario'],'sampled_frames':len(frames),
            'car_clipping_frames':sum(f['cars_visible']<m['players'] for f in frames),
            'corridor_clipping_frames':sum(f['full_ahead']<m['players'] for f in frames),
            'car_floor_honoured':True,'areas_sum_to_one':True,'completed_merges_share_one_projection':True})
    (root/'traces'/'invariant-tests.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    import sys
    run(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parents[1])
