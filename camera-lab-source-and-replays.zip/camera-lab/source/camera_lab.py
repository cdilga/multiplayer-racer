"""Deterministic 2-D camera lab. Scripted cars; actual power masks and camera fits.
Run: python camera_lab.py --out /path/to/camera-lab [--scenario 1] [--preview]
Dependencies: numpy scipy pillow shapely opencv-python; ffmpeg on PATH.
No assets, network requests, hidden video footage, or game-repository dependencies.
"""
from __future__ import annotations
import argparse, dataclasses, json, math, os, subprocess, time
from pathlib import Path
from dataclasses import dataclass, field
from functools import lru_cache
import numpy as np
from scipy.optimize import linprog
from shapely.geometry import Polygon, Point, MultiPolygon
from shapely.ops import unary_union, nearest_points
from PIL import Image, ImageDraw, ImageFont
import cv2

W,H=1080,560
HEADER,FOOTER=88,126
OH=HEADER+H+FOOTER
FPS=20
CAR_LENGTH,CAR_WIDTH=4.5,2.1

@dataclass(frozen=True)
class Budget:
    lookahead_seconds: float=2.0
    reaction_seconds: float=.35
    braking_deceleration: float=7.0
    minimum_road_ahead: float=24.0
    stopping_margin: float=8.0
    target_car_length_px: float=25.0
    minimum_car_length_px: float=18.0
    population_area_weight: float=.8
    merge_hold_seconds: float=.45
    transition_seconds: float=1.6
    merge_scale_fraction: float=.975
    split_scale_fraction: float=.865
    seam_inset_px: float=12.0
    area_response_seconds: float=1.1
    camera_response_seconds: float=.24

B=Budget()
PREF=B.target_car_length_px/CAR_LENGTH
FLOOR=B.minimum_car_length_px/CAR_LENGTH

def ahead(v):
    v=max(0.,float(v))
    return max(B.minimum_road_ahead, v*B.lookahead_seconds,
               v*B.reaction_seconds+v*v/(2*B.braking_deceleration)+B.stopping_margin)

def smooth(x):
    x=np.clip(x,0.,1.)
    return x*x*(3-2*x)

def signed_area(p):
    if len(p)<3:return 0.
    return .5*float(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1)))

def area(p):return abs(signed_area(p))

def clip(poly, n, b):
    """Convex polygon clipped to n dot x <= b; float geometry, not image masks."""
    if len(poly)==0:return np.empty((0,2))
    vals=poly@n-b
    out=[]
    a=poly[-1]; fa=vals[-1]
    for z,fz in zip(poly,vals):
        if (fa<=1e-8)!=(fz<=1e-8):
            den=fa-fz
            if abs(den)>1e-15:out.append(a+(z-a)*(fa/den))
        if fz<=1e-8:out.append(z)
        a=z;fa=fz
    return np.array(out,dtype=float).reshape(-1,2)

RECT=np.array([[0.,0.],[W,0.],[W,H],[0.,H]])

def power_cells(sites,weights):
    cells=[]
    norm=np.sum(sites*sites,axis=1)
    for i,a in enumerate(sites):
        p=RECT.copy()
        for j,b in enumerate(sites):
            if i==j:continue
            p=clip(p,2*(b-a),norm[j]-norm[i]+weights[i]-weights[j])
            if len(p)<3:break
        cells.append(p)
    return cells

def solve_weights(sites,targets,initial=None):
    """Damped Newton area solve. Gauge fixed by zero-mean weights.
    J_ij = -shared_edge_length / (2*site_distance); row sums zero.
    A small finite-difference fallback handles degenerate adjacency.
    """
    n=len(sites)
    w=np.zeros(n) if initial is None else np.array(initial,float).copy()
    targets=np.array(targets,float);targets=targets/targets.sum()*W*H
    for it in range(70):
        cells=power_cells(sites,w); aa=np.array([area(p) for p in cells])
        err=targets-aa
        if max(abs(err)) < W*H*2e-6:break
        J=np.zeros((n,n))
        for i,p in enumerate(cells):
            for a,b in zip(p,np.roll(p,-1,axis=0)):
                mid=(a+b)/2
                if min(mid[0],W-mid[0],mid[1],H-mid[1])<1e-5:continue
                d=np.sum((sites-mid)**2,axis=1)-w
                d[i]=np.inf
                j=int(np.argmin(d));dist=np.linalg.norm(sites[j]-sites[i])
                coeff=np.linalg.norm(b-a)/(2*dist)
                J[i,i]+=coeff;J[i,j]-=coeff
        J=(J+J.T)/2
        # Gauge is the only intended null direction.
        try:
            delta=np.linalg.solve(J+np.ones((n,n))/n,err)
        except np.linalg.LinAlgError:
            delta=np.linalg.lstsq(J+np.ones((n,n))/n,err,rcond=1e-9)[0]
        normerr=float(np.linalg.norm(err))
        accepted=False
        for k in range(18):
            cand=w+delta*(.5**k);cand-=cand.mean()
            ca=np.array([area(p) for p in power_cells(sites,cand)])
            if min(ca)>1e-5 and np.linalg.norm(targets-ca)<normerr:
                w=cand;accepted=True;break
        if not accepted:
            w+=err*.05;w-=w.mean()
    cells=power_cells(sites,w)
    return w, float(max(abs(np.array([area(p) for p in cells])-targets))/(W*H))


def edge_constraints(p):
    if signed_area(p)<0:p=p[::-1]
    d=np.roll(p,-1,axis=0)-p
    norms=np.c_[d[:,1],-d[:,0]]
    ll=np.linalg.norm(norms,axis=1)
    keep=ll>1e-7
    norms=norms[keep]/ll[keep,None]
    bb=np.sum(norms*p[keep],axis=1)
    return norms,bb


def inscribed_rectangle(reg):
    """Coarse search, exact final containment check. Safe, deliberately conservative."""
    step=14.
    rw,rh=int(W/step)+1,int(H/step)+1
    raster=np.zeros((rh,rw),np.uint8)
    pp=np.array(reg.exterior.coords[:-1])/step
    cv2.fillPoly(raster,[np.rint(pp).astype(np.int32)],255)
    for hole in reg.interiors:
        cv2.fillPoly(raster,[np.rint(np.array(hole.coords)/step).astype(np.int32)],0)
    raster=cv2.erode(raster,np.ones((3,3),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
    heights=np.zeros(rw,int);best=(0,None)
    for y,row in enumerate(raster):
        heights=np.where(row>0,heights+1,0)
        stack=[]
        for x in range(rw+1):
            h=heights[x] if x<rw else 0
            start=x
            while stack and stack[-1][1]>h:
                left,hh=stack.pop();start=left
                aa=(x-left)*hh
                if aa>best[0]:best=(aa,(left,y-hh+1,x,y+1))
            if not stack or stack[-1][1]<h:stack.append((start,int(h)))
    if best[1] is None:return np.empty((0,2))
    x0,y0,x1,y1=np.array(best[1])*step
    p=np.array([[x0,y0],[x1,y0],[x1,y1],[x0,y1]])
    # This predicate is what prevents a coarse-grid fit from stealing another view's pixels.
    for shrink in [0., 1., 3., 7., 14.]:
        pp=np.array([[x0+shrink,y0+shrink],[x1-shrink,y0+shrink],[x1-shrink,y1-shrink],[x0+shrink,y1-shrink]])
        if x1-x0<=2*shrink or y1-y0<=2*shrink:break
        if Polygon(pp).difference(reg).area<1e-4:return pp
    return np.empty((0,2))


def region_geometry(cells,ids):
    ps=[Polygon(cells[i]) for i in ids if len(cells[i])>=3]
    if not ps:return None,np.empty((0,2)),'empty'
    reg=unary_union(ps)
    # Geometry comes from identical shared halfplanes; snap away < 1e-7 roundoff only.
    reg=reg.buffer(1e-7).buffer(-1e-7)
    if isinstance(reg,MultiPolygon):
        major=max(reg.geoms,key=lambda p:p.area)
        connected=(reg.area-major.area)<.0001
        if not connected:
            idx=max(ids,key=lambda i:area(cells[i]))
            return reg,cells[idx],'disconnected: largest-cell fallback'
        reg=major
    p=np.array(reg.exterior.coords[:-1])
    if signed_area(p)<0:p=p[::-1]
    # Kernel is contained in the true union. Never use a hull that steals another view.
    kernel=RECT.copy()
    nn,bb=edge_constraints(p)
    for n,b in zip(nn,bb):
        kernel=clip(kernel,n,b)
        if len(kernel)<3:break
    if area(kernel)<reg.area*.75:
        rect=inscribed_rectangle(reg)
        if area(rect)>area(kernel):
            return reg,rect,'conservative inscribed rectangle'
    if area(kernel)<max(100.,reg.area*.08):
        idx=max(ids,key=lambda i:area(cells[i]))
        return reg,cells[idx],'small kernel: largest-cell fallback'
    return reg,kernel,'convex' if abs(reg.area-area(kernel))<.1 else 'conservative union kernel'


def feasible_translation(n,b,s,points):
    support=np.max(points@n.T,axis=0)
    lim=b-B.seam_inset_px-s*support
    out=np.array([[-1e6,-1e6],[1e6,-1e6],[1e6,1e6],[-1e6,1e6]])
    for a,c in zip(n,lim):out=clip(out,a,c)
    return out


def closest_translation(p,want):
    if len(p)<3:return want
    poly=Polygon(p)
    pt=Point(want)
    if poly.covers(pt):return want
    q=nearest_points(poly,pt)[0]
    return np.array(q.coords[0])


def camera_fit(poly,points,car_points,previous=None,dt=.05):
    if len(poly)<3:
        return {'s':FLOOR,'t':np.array([W/2,H/2])-FLOOR*np.mean(points,axis=0),'fit':0.,'limited':True}
    n,b=edge_constraints(poly)
    support=np.max(points@n.T,axis=0)
    A=np.c_[support,n]
    res=linprog([-1.,0.,0.],A_ub=A,b_ub=b-B.seam_inset_px,
                bounds=[(0.,PREF*4),(None,None),(None,None)],method='highs')
    fit=max(0.,res.x[0]) if res.success else 0.
    s=max(FLOOR,min(PREF,fit*.999))
    centroid=np.array(Polygon(poly).centroid.coords[0])
    # Centre the road footprint, not the present car cluster.
    ctr=(points.min(axis=0)+points.max(axis=0))/2
    want=centroid-s*ctr
    if previous is not None:
        alpha=1-math.exp(-dt/B.camera_response_seconds)
        s=previous['s']+(s-previous['s'])*alpha
        # Emergency zoom out is allowed when the current scale cannot fit.
        if fit>=FLOOR and s>fit:s=fit*.999
        want=previous['t']+(want-previous['t'])*alpha
    tp=feasible_translation(n,b,s,points)
    limited=len(tp)<3
    if limited:
        # Don't shrink cars below the declared floor to manufacture a 'pass'.
        # Retain the car cluster first, then show as much road as the cell permits.
        tp=feasible_translation(n,b,s,car_points)
    if len(tp)>=3:want=closest_translation(tp,want)
    return {'s':float(s),'t':want,'fit':float(fit),'limited':bool(limited)}


class Route:
    def __init__(self,pts,width=7.,layer=0,name='ROAD'):
        self.pts=np.array(pts,float);self.width=width;self.layer=layer;self.name=name
        self.ds=np.linalg.norm(np.diff(self.pts,axis=0),axis=1)
        self.arc=np.r_[0.,np.cumsum(self.ds)]
    def at(self,s):
        ss=np.asarray(s,float)
        # Linear extrapolation at road ends makes the required horizon explicit.
        x=np.interp(ss,self.arc,self.pts[:,0]);y=np.interp(ss,self.arc,self.pts[:,1])
        val=np.stack([x,y],axis=-1)
        if np.ndim(ss)==0:
            if ss<0:val=self.pts[0]+ss*(self.pts[1]-self.pts[0])/self.ds[0]
            if ss>self.arc[-1]:val=self.pts[-1]+(ss-self.arc[-1])*(self.pts[-1]-self.pts[-2])/self.ds[-1]
        return val
    def tangent(self,s):
        v=self.at(s+.1)-self.at(s-.1)
        return v/max(np.linalg.norm(v),1e-8)
    def nearest_arc(self,p):
        return float(self.arc[np.argmin(np.linalg.norm(self.pts-p,axis=1))])

@dataclass
class Car:
    id:int
    route:Route
    arc:float
    speed:float
    pos:np.ndarray=field(init=False)
    heading:np.ndarray=field(init=False)
    horizon:float=field(init=False)
    future:np.ndarray=field(init=False)
    corridor:np.ndarray=field(init=False)
    body:np.ndarray=field(init=False)
    def __post_init__(self):
        self.pos=self.route.at(self.arc);self.heading=self.route.tangent(self.arc)
        self.horizon=ahead(self.speed)
        sa=self.arc+np.linspace(0,self.horizon,max(16,int(self.horizon/2)+1))
        self.future=self.route.at(sa)
        tan=np.array([self.route.tangent(float(s)) for s in sa])
        perp=np.c_[-tan[:,1],tan[:,0]]
        self.corridor=np.stack([self.future-perp*self.route.width/2,
                                self.future+perp*self.route.width/2],axis=1)
        side=np.array([-self.heading[1],self.heading[0]])
        self.body=np.array([self.pos+u*self.heading*CAR_LENGTH/2+v*side*CAR_WIDTH/2
                            for u,v in [(1,1),(1,-1),(-1,-1),(-1,1)]])

@dataclass
class Node:
    key:str
    cars:list[int]
    children:list['Node']=field(default_factory=list)
    u:float=0.
    hold:float=0.
    want:bool=False
    camera:dict|None=None
    fit:float=0.
    geom:object=None
    poly:np.ndarray|None=None
    kind:str=''
    layer_ok:bool=True
    def allnodes(self):
        return [z for c in self.children for z in c.allnodes()]+[self]


def make_node(key,*children):
    return Node(key,[i for c in children for i in c.cars],list(children))

def atomic_sites(groups,anchors):
    out=np.zeros((sum(len(g) for g in groups),2))
    for group,anchor in zip(groups,anchors):
        n=len(group)
        if n==1:offsets=[[0.,0.]]
        elif n==4:offsets=[[-22,-20],[22,-20],[-22,20],[22,20]]
        else:
            offsets=[[26*math.cos(2*math.pi*k/n+.3),24*math.sin(2*math.pi*k/n+.3)] for k in range(n)]
        for i,off in zip(group,offsets):out[i]=np.array(anchor)*[W,H]+off
    return out


class Scenario:
    def __init__(self,index):
        self.index=index;self.routes=[];self.roots=[];self.duration=18.;self.time_factor=1.
        self.names={1:'TWELVE CONVERGE + FOUR OUTSIDERS',2:'A FORK INTERRUPTS A MERGE',
                    3:'LONG CONVOY -> SIXTEEN ISOLATED VIEWS',4:'HAIRPIN + A SEPARATE BRIDGE LEVEL'}
        if index==1:self.setup1()
        if index==2:self.setup2()
        if index==3:self.setup3()
        if index==4:self.setup4()
        self.nodes=[x for r in self.roots for x in r.allnodes()]
        self.leaves=[x for x in self.nodes if not x.children]
        self.N=len(self.sites)

    def setup1(self):
        self.duration=20.
        yy=np.linspace(-100,500,650)
        for lane in [-1,0,1]:
            xx=lane*(3.4+106.6*(1-smooth(yy/290)))
            self.routes.append(Route(np.c_[xx,-yy],7,name='MERGE APPROACH'))
        for k in range(4):
            self.routes.append(Route([[-200+1000*k,400+180*k],[700+1000*k,400+180*k]],7,name='OUTSIDER'))
        groups=[list(range(i,i+4)) for i in [0,4,8]]+[[i] for i in range(12,16)]
        anchors=[(.17,.25),(.5,.23),(.83,.25),(.12,.88),(.37,.87),(.63,.88),(.88,.86)]
        self.sites=atomic_sites(groups,anchors)
        leaves=[Node('ABCD'[i] if i<3 else f'O{i-2}',g) for i,g in enumerate(groups)]
        ab=make_node('AB',leaves[0],leaves[1]);pack=make_node('PACK',ab,leaves[2])
        self.roots=[pack]+leaves[3:]
        self.starts=[r.nearest_arc([r.pts[0,0],-10]) for r in self.routes[:3]]
        # Use common longitudinal y, giving a visible three-ramp funnel.
    def cars1(self,t):
        cars=[]
        y=12+13*t
        for g in range(3):
            r=self.routes[g]
            for k in range(4):
                yy=y-5.4*k
                xx=[-1,0,1][g]*(3.4+106.6*(1-smooth(yy/290)))
                s=float(np.interp(yy,-r.pts[:,1],r.arc))
                eps=.02
                def xy(q):return np.array([[-1,0,1][g]*(3.4+106.6*(1-smooth(q/290))),-q])
                v=np.linalg.norm(xy(yy+13*eps)-xy(yy-13*eps))/(2*eps)
                cars.append(Car(g*4+k,r,s,v))
        for k in range(4):cars.append(Car(12+k,self.routes[3+k],160+12*t,12.))
        return cars

    def setup2(self):
        self.duration=23.
        yy=np.linspace(-80,430,950);self.fork_y=12+13*6.4
        for branch in [False,True]:
            for side in [-1,1]:
                mag=120-.40*yy
                if branch:
                    z=yy-self.fork_y
                    bump=60*smooth(z/30)*(1-smooth((z-48)/85))
                    mag=mag+bump
                mag=np.maximum(8,mag)
                self.routes.append(Route(np.c_[side*mag,-yy],7,name='SELECTED FORK' if branch else 'INITIAL INTENT'))
        groups=[list(range(4)),list(range(4,8))]
        self.sites=atomic_sites(groups,[(.25,.43),(.75,.57)])
        self.roots=[make_node('PAIR',Node('A',groups[0]),Node('B',groups[1]))]
    def cars2(self,t):
        cars=[];branch=t>=6.4;y=12+13*t
        for g in range(2):
            r=self.routes[(2 if branch else 0)+g]
            for k in range(4):
                yy=y-5.4*k
                # Individual cars take the branch only upon reaching its physical junction.
                route=r if (not branch or yy>=self.fork_y) else self.routes[g]
                s=float(np.interp(yy,-route.pts[:,1],route.arc))
                dy=max(abs(route.tangent(s)[1]),.25)
                cars.append(Car(g*4+k,route,float(s),13/dy))
                # At the decision event, upcoming route prediction switches before all cars arrive.
                if branch and yy<self.fork_y:
                    chosen=self.routes[2+g]
                    ss=chosen.nearest_arc(cars[-1].pos)
                    cars[-1]=Car(g*4+k,chosen,ss,13/dy)
        return cars

    def setup3(self):
        self.duration=18.;self.time_factor=60/18
        self.routes=[Route([[-1000,0],[7000,0]],7,name='LONG STRAIGHT')]
        # Snake ordering keeps each binary subtree connected on screen.
        coords=[]
        for y in range(4):
            xs=list(range(4)) if y%2==0 else list(range(3,-1,-1))
            for x in xs:coords.append([(x+.5)/4*W+(y%2)*8,(y+.5)/4*H+(x%2)*5])
        self.sites=np.array(coords)
        nodes=[Node(str(i+1),[i]) for i in range(16)]
        depth=0
        while len(nodes)>1:
            nodes=[make_node(f'L{depth}-{i}',nodes[i],nodes[i+1]) for i in range(0,len(nodes),2)];depth+=1
        self.roots=nodes
        for node in self.roots[0].allnodes():
            if node.children:node.u=1.;node.want=True
    def cars3(self,t):
        f=float(smooth((t-5)/48));spacing=5.3+72*f
        x=np.clip((t-5)/48,0,1)
        deriv=72*6*x*(1-x)/48 if 5<t<53 else 0.
        cars=[]
        for i in range(16):
            pos=100+12*t+i*spacing
            speed=12+i*deriv
            cars.append(Car(i,self.routes[0],pos+1000,speed))
        return cars

    def setup4(self):
        self.duration=18.
        entrance=np.c_[np.linspace(-250,30,300),np.full(300,22.)]
        a=np.linspace(math.pi/2,-math.pi/2,140)
        bend=np.c_[30+22*np.cos(a),22*np.sin(a)]
        exit=np.c_[np.linspace(30,-400,450),np.full(450,-22.)]
        self.routes=[Route(np.vstack([entrance,bend[1:],exit[1:]]),7,0,'HAIRPIN'),
                     Route([[0,300],[0,-400]],8,1,'BRIDGE / LEVEL 1')]
        groups=[list(range(6)),list(range(6,12)),list(range(12,16))]
        self.sites=atomic_sites(groups,[(.29,.76),(.29,.24),(.89,.5)])
        a,b,c=[Node(x,g) for x,g in zip('ABC',groups)]
        # All-node candidate exists but is vetoed by explicit level metadata.
        ab=make_node('HAIRPIN',a,b);self.roots=[make_node('CROSS_LEVEL',ab,c)]
        self.startA=self.routes[0].nearest_arc([-75,22])
        self.startB=self.routes[0].nearest_arc([-15,-22])
    def cars4(self,t):
        cars=[]
        for i in range(6):cars.append(Car(i,self.routes[0],self.startA+12*t-i*5.3,12.))
        for k in range(6):cars.append(Car(6+k,self.routes[0],self.startB+9*t-k*5.3,9.))
        for k in range(4):cars.append(Car(12+k,self.routes[1],165+12*t-k*5.3,12.))
        return cars

    def cars(self,t):return getattr(self,f'cars{self.index}')(t)
    def message(self,t,views):
        if self.index==1:
            if t<4:return 'Three four-car packs approach. Four solo views retain their own screen share.'
            if t<10:return 'Common framing becomes feasible BEFORE the ramps meet. Watch the seams converge.'
            return 'The converging pack should inherit one large region; the four outsiders retain independent views.'
        if self.index==2:
            if t<6.4:return 'Initial route intent permits a merge attempt. Cameras begin converging.'
            if t<13:return 'Fork choice changes the road-ahead footprint. Reverse the unfinished transition.'
            return 'The branches return. The same geometry test decides whether to merge again.'
        if self.index==3:
            if t<12:return 'A compact sixteen-car convoy fits one view. Neighbour distance is not the fit test.'
            if t<39:return 'The convoy stretches and accelerates. Whole-group road footprints force splits.'
            return 'Sixteen solo views: acceleration stresses the road budget; steady speeds can restore visibility.'
        if t<6:return 'Nearby hairpin legs may share a camera if BOTH upcoming road corridors fit.'
        if t<12:return 'Road-following lookahead bends around the apex. The dashed tangent is the wrong forecast.'
        return 'Different road levels keep separate views, even when their plan-view coordinates coincide.'


class Engine:
    def __init__(self,sc):
        self.sc=sc;self.N=sc.N;self.events=[];self.weight_cache={};self.frame_no=0
        groups=self.active_groups()
        targets=self.targets(groups)
        self.weights,self.area_error=solve_weights(sc.sites,targets)
        self.weight_goal=self.weights.copy();self.groupkey=None;self.cameras_prev={}
        self.prev_cars=None;self.prev_effective=None
    def active_groups(self):
        def visit(n):
            if not n.children or n.u>=1-1e-8:return [n.cars]
            return [g for c in n.children for g in visit(c)]
        return [g for r in self.sc.roots for g in visit(r)]
    def targets(self,groups):
        t=np.zeros(self.N)
        K=len(groups)
        for g in groups:
            share=B.population_area_weight*len(g)/self.N+(1-B.population_area_weight)/K
            t[g]=share/len(g)
        return t
    def step(self,t,dt):
        cars=self.sc.cars(t);byid={c.id:c for c in cars}
        groups=self.active_groups();key=tuple(tuple(g) for g in groups)
        if key!=self.groupkey:
            if key not in self.weight_cache:
                goal,err=solve_weights(self.sc.sites,self.targets(groups),self.weights)
                self.weight_cache[key]=(goal,err)
            self.weight_goal,self.area_error=self.weight_cache[key];self.groupkey=key
        alpha=1-math.exp(-dt/B.area_response_seconds)
        self.weights+=alpha*(self.weight_goal-self.weights)
        cells=power_cells(self.sc.sites,self.weights)
        # Fit every candidate to actual polygons and road-width footprints.
        for n in self.sc.nodes:
            n.geom,n.poly,n.kind=region_geometry(cells,n.cars)
            members=[byid[i] for i in n.cars]
            pts=np.vstack([np.vstack([c.corridor.reshape(-1,2),c.body]) for c in members])
            cp=np.vstack([c.body for c in members])
            n.camera=camera_fit(n.poly,pts,cp,n.camera,dt)
            n.fit=n.camera['fit']
            n.layer_ok=len({c.route.layer for c in members})==1
        for n in self.sc.nodes:
            if not n.children:continue
            previous=n.u;previous_want=n.want
            high=n.fit>=PREF*B.merge_scale_fraction and n.layer_ok and 'disconnected' not in n.kind
            low=n.fit<PREF*B.split_scale_fraction or not n.layer_ok or 'disconnected' in n.kind
            if high:
                n.hold+=dt
                if n.hold>=B.merge_hold_seconds:n.want=True
            elif low:
                n.hold=0.;n.want=False
            else:n.hold=0.
            n.u=float(np.clip(n.u+(dt/B.transition_seconds)*(1 if n.want else -1),0,1))
            if previous==0 and n.u>0:self.events.append({'t':round(t,3),'type':'merge_start','node':n.key,'cars':n.cars})
            if previous==1 and n.u<previous:
                self.events.append({'t':round(t,3),'type':'split_start','node':n.key,'cars':n.cars})
            elif 0<previous<1 and previous_want and not n.want:
                self.events.append({'t':round(t,3),'type':'reverse_tween','node':n.key,'cars':n.cars})
            if previous<1 and n.u==1:self.events.append({'t':round(t,3),'type':'merge_complete','node':n.key,'cars':n.cars,'projection_gap_px':0.})
            if previous>0 and n.u==0:self.events.append({'t':round(t,3),'type':'split_complete','node':n.key,'cars':n.cars})
        effective={}
        def assign(n,chain):
            if n.children:
                for c in n.children:assign(c,chain+[n])
            else:
                cam={'s':n.camera['s'],'t':n.camera['t'].copy()}
                for anc in reversed(chain):
                    u=float(smooth(anc.u))
                    cam['s']=(1-u)*cam['s']+u*anc.camera['s']
                    cam['t']=(1-u)*cam['t']+u*anc.camera['t']
                for i in n.cars:effective[i]=cam
        for r in self.sc.roots:assign(r,[])
        # Collapse exactly equal projections only; tweening cameras retain distinct masks.
        views=[]
        for i in range(self.N):
            cam=effective[i]
            found=None
            for v in views:
                if abs(v['cam']['s']-cam['s'])<1e-7 and np.linalg.norm(v['cam']['t']-cam['t'])<1e-6:
                    found=v;break
            if found is None:views.append({'ids':[i],'cam':cam})
            else:found['ids'].append(i)
        stats=[]
        for v in views:
            v['geom'],v['poly'],v['kind']=region_geometry(cells,v['ids'])
            v['area']=sum(area(cells[i]) for i in v['ids'])/(W*H)
            v['mask']=np.zeros((H,W),np.uint8)
            for i in v['ids']:
                if len(cells[i])>=3:cv2.fillConvexPoly(v['mask'],np.rint(cells[i]).astype(np.int32),255)
            v['safe']=cv2.erode(v['mask'],np.ones((19,19),np.uint8),borderType=cv2.BORDER_CONSTANT,borderValue=0)
            for i in v['ids']:
                c=byid[i];cam=v['cam']
                q=c.corridor*cam['s']+cam['t']
                pp=np.rint(q).astype(int)
                ok=(pp[:,:,0]>=0)&(pp[:,:,0]<W)&(pp[:,:,1]>=0)&(pp[:,:,1]<H)
                lookup=v['safe'][np.clip(pp[:,:,1],0,H-1),np.clip(pp[:,:,0],0,W-1)]>0
                both=(ok&lookup).all(axis=1)
                bad=np.flatnonzero(~both)
                prefix=float(bad[0]/(len(both)-1)) if len(bad) else 1.
                body=np.rint(c.body*cam['s']+cam['t']).astype(int)
                carok=bool(np.all((body[:,0]>=0)&(body[:,0]<W)&(body[:,1]>=0)&(body[:,1]<H)))
                if carok:carok=bool(np.all(v['mask'][body[:,1],body[:,0]]>0))
                stat={'id':i+1,'full_ahead':bool(both.all()),'ahead_fraction':prefix,
                      'required_distance':round(c.horizon,3),'visible_distance':round(prefix*c.horizon,3),
                      'car_px':round(CAR_LENGTH*cam['s'],2),'car_visible':carok,
                      'area':round(v['area'],5),'scale':round(cam['s'],5)}
                stats.append(stat)
            v['stats']=[x for x in stats if x['id']-1 in v['ids']]
        self.frame_no+=1
        state={'t':round(t,4),'views':views,'cells':cells,'cars':cars,'effective':effective,
               'stats':stats,'nodes':self.sc.nodes,'weights':self.weights.copy(),'message':self.sc.message(t,len(views))}
        return state

# Renderer: a top-down toy world, not a chart or a stylised prediction of production assets.
BG=(14,20,29);GROUND=(28,39,44);ROAD=(63,73,78);EDGE=(146,160,158)
WHITE=(236,243,239);MUTED=(153,176,184);TEAL=(79,225,180);WARN=(255,115,94)
COLORS=[(255,186,67),(103,207,251),(237,138,214),(172,222,99),
        (248,137,99),(159,167,253),(70,221,200),(241,221,109),
        (243,131,154),(116,187,235),(183,220,133),(225,181,132),
        (163,153,243),(114,223,196),(241,176,222),(214,217,229)]
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
@lru_cache(None)
def font(n,bold=False):return ImageFont.truetype(BOLD if bold else FONT,n)

def ipts(p):return np.rint(np.clip(p,-15000,15000)).astype(np.int32)

def dashed_line(im,points,color,width=1,dash=8,gap=7):
    # Dash each polyline in world-sampled sections; no model-generated pixels.
    for a,b in zip(points,np.roll(points,-1,axis=0)):
        d=np.linalg.norm(b-a)
        if d<1:continue
        if min(a[0],b[0])>W or max(a[0],b[0])<0 or min(a[1],b[1])>H or max(a[1],b[1])<0:continue
        for u in np.arange(0,d,dash+gap):
            p=a+(b-a)*u/d;q=a+(b-a)*min(u+dash,d)/d
            cv2.line(im,tuple(ipts(p)),tuple(ipts(q)),color,width,cv2.LINE_AA)


def render_world(sc,state,v):
    im=np.empty((H,W,3),np.uint8);im[:]=GROUND
    s=v['cam']['s'];tr=v['cam']['t']
    # World-space grid provides scale continuity; it is not another camera layer.
    step=20*s
    if step>5:
        for x in np.arange(tr[0]%step,W,step):cv2.line(im,(int(x),0),(int(x),H),(35,48,51),1)
        for y in np.arange(tr[1]%step,H,step):cv2.line(im,(0,int(y)),(W,int(y)),(35,48,51),1)
    routes=sc.routes
    for ri,r in enumerate(routes):
        if sc.index==2 and ri<2:
            pts=r.pts*s+tr
            cv2.polylines(im,[ipts(pts)],False,(46,60,63),max(1,int(r.width*s)),cv2.LINE_AA)
            continue
        pts=r.pts*s+tr
        if max(pts[:,0])<-50 or min(pts[:,0])>W+50 or max(pts[:,1])<-50 or min(pts[:,1])>H+50:continue
        wid=max(3,int(r.width*s))
        edge=EDGE if r.layer==0 else (137,144,192)
        pavement=ROAD if r.layer==0 else (60,64,90)
        cv2.polylines(im,[ipts(pts)],False,edge,wid+5,cv2.LINE_AA)
        cv2.polylines(im,[ipts(pts)],False,pavement,wid,cv2.LINE_AA)
        # Road-aligned centre dashes, sampled by physical distance.
        for a in np.arange(0,r.arc[-1],14.):
            line=r.at(np.array([a,a+4.]))*s+tr
            if max(line[:,0])<0 or min(line[:,0])>W or max(line[:,1])<0 or min(line[:,1])>H:continue
            cv2.line(im,tuple(ipts(line[0])),tuple(ipts(line[1])),(157,168,168),1,cv2.LINE_AA)
        if sc.index==3:
            for a in np.arange(0,r.arc[-1],50.):
                p=r.at(a)*s+tr
                if 0<p[0]<W and -30<p[1]<H:
                    cv2.putText(im,str(int(a-1000)),(int(p[0]),int(p[1]-wid/2-7)),cv2.FONT_HERSHEY_SIMPLEX,.34,(137,151,154),1,cv2.LINE_AA)
    owned=set(v['ids'])
    statmap={st['id']-1:st for st in v['stats']}
    # All owned upcoming lanes, not a misleading straight velocity ray.
    for c in state['cars']:
        if c.id not in owned:continue
        q=c.corridor*s+tr
        hull=np.vstack([q[:,0],q[::-1,1]])
        tint=im.copy()
        cv2.fillPoly(tint,[ipts(hull)],TEAL)
        im=cv2.addWeighted(tint,.12,im,.88,0)
        centre=c.future*s+tr
        cv2.polylines(im,[ipts(centre)],False,TEAL,2,cv2.LINE_AA)
        # Terminal cross-bar is the full required distance; clipping must not move it inward.
        cv2.line(im,tuple(ipts(q[-1,0])),tuple(ipts(q[-1,1])),TEAL,3,cv2.LINE_AA)
        tip=centre[-1];cv2.circle(im,tuple(ipts(tip)),3,TEAL,-1,cv2.LINE_AA)
        if sc.index==4 and c.id==0:
            a=c.pos*s+tr;b=(c.pos+c.heading*c.horizon)*s+tr
            # Reference only: straight-line anticipation misses a bend.
            for u in np.arange(0,1,.09):
                cv2.line(im,tuple(ipts(a+(b-a)*u)),tuple(ipts(a+(b-a)*min(1,u+.04))),WHITE,1,cv2.LINE_AA)
    # Nonowned cars are context; no duplicate owner tags.
    for c in state['cars']:
        p=c.pos*s+tr
        if not (-40<p[0]<W+40 and -40<p[1]<H+40):continue
        own=c.id in owned
        color=COLORS[c.id%len(COLORS)] if own else (111,121,125)
        body=c.body*s+tr
        cv2.fillConvexPoly(im,ipts(body+np.array([2,3])),(12,18,21),cv2.LINE_AA)
        cv2.fillConvexPoly(im,ipts(body),color,cv2.LINE_AA)
        cv2.polylines(im,[ipts(body)],True,(17,26,32),1,cv2.LINE_AA)
        nose=p+c.heading*CAR_LENGTH*.30*s
        cv2.circle(im,tuple(ipts(nose)),max(1,int(s*.30)),WHITE,-1,cv2.LINE_AA)
        if own:
            # Roof identity is intentionally inside the car. UI must not fake car visibility.
            label=f'{c.id+1:02d}'
            fs=.32 if s<5 else .37
            (tw,th),_=cv2.getTextSize(label,cv2.FONT_HERSHEY_SIMPLEX,fs,1)
            cv2.putText(im,label,(int(p[0]-tw/2),int(p[1]+th/2)),cv2.FONT_HERSHEY_SIMPLEX,fs,(13,23,28),1,cv2.LINE_AA)
            if not statmap[c.id]['full_ahead']:
                # Dashed warning ring remains attached to the owned car.
                cv2.circle(im,tuple(ipts(p)),int(max(11,CAR_LENGTH*s*.68)),WARN,1,cv2.LINE_AA)
    return im


def text(draw,xy,txt,size=16,fill=WHITE,bold=False):
    draw.text(xy,txt,font=font(size,bold),fill=fill)


def render(sc,state):
    canvas=np.zeros((H,W,3),np.uint8);canvas[:]=BG
    owner=np.full((H,W),-1,np.int16)
    for j,v in enumerate(state['views']):
        world=render_world(sc,state,v)
        mask=v['mask']>0
        canvas[mask]=world[mask];owner[mask]=j
    # Fade only the seam ink as projections agree. Do not crossfade world images.
    cars_by_id={c.id:c for c in state['cars']}
    for i,poly in enumerate(state['cells']):
        for a,b in zip(poly,np.roll(poly,-1,axis=0)):
            mid=(a+b)/2
            if min(mid[0],W-mid[0],mid[1],H-mid[1])<1e-4:continue
            dv=np.sum((sc.sites-mid)**2,axis=1)-state['weights'];dv[i]=np.inf
            j=int(np.argmin(dv))
            if i>=j:continue
            ca,cb=state['effective'][i],state['effective'][j]
            probes=np.vstack([cars_by_id[i].pos,cars_by_id[j].pos,cars_by_id[i].future[-1],cars_by_id[j].future[-1]])
            gap=float(np.max(np.linalg.norm((ca['s']-cb['s'])*probes+ca['t']-cb['t'],axis=1)))
            alpha=min(1.,gap/18.)
            if alpha<1e-5:continue
            lo=np.maximum([0,0],np.floor(np.minimum(a,b)-5).astype(int))
            hi=np.minimum([W,H],np.ceil(np.maximum(a,b)+6).astype(int))
            if np.any(hi<=lo):continue
            roi=canvas[lo[1]:hi[1],lo[0]:hi[0]];overlay=roi.copy()
            cv2.line(overlay,tuple(ipts(a-lo)),tuple(ipts(b-lo)),(6,12,17),5,cv2.LINE_AA)
            cv2.line(overlay,tuple(ipts(a-lo)),tuple(ipts(b-lo)),(168,189,194),1,cv2.LINE_AA)
            canvas[lo[1]:hi[1],lo[0]:hi[0]]=cv2.addWeighted(overlay,alpha,roi,1-alpha,0)
    cv2.rectangle(canvas,(0,0),(W-1,H-1),(126,151,160),1,cv2.LINE_AA)
    im=Image.new('RGB',(W,OH),BG);im.paste(Image.fromarray(canvas),(0,HEADER));d=ImageDraw.Draw(im)
    text(d,(22,12),f'CAMERA LAB  /  0{sc.index}',14,TEAL,True)
    text(d,(22,33),sc.names[sc.index],24,WHITE,True)
    text(d,(22,65),'Code-rendered toy  |  Shared orientation  |  No image crossfades  |  Route-width visibility tested',12,MUTED)
    clock=f'{state["t"]:04.1f}s'
    if sc.time_factor!=1:clock+=f'  ({sc.time_factor:.1f}x replay)'
    text(d,(W-240,12),clock,14,MUTED)
    # Place one badge inside each view, using its distance transform rather than a bounding-box corner.
    for v in state['views']:
        mask=v['mask'];dist=cv2.distanceTransform(np.pad(mask,1),cv2.DIST_L2,3)[1:-1,1:-1]
        if dist.max()<15:continue
        # Prefer a clear upper zone; avoid laying a badge over an owned car.
        penalty=np.zeros_like(dist)
        for c in state['cars']:
            if c.id in v['ids']:
                p=c.pos*v['cam']['s']+v['cam']['t']
                cv2.circle(penalty,tuple(ipts(p)),45,60,-1)
        yy=np.arange(H)[:,None]
        score=np.minimum(dist,48)-yy*.05-penalty
        score[dist<28]=-1e6
        py,px=np.unravel_index(np.argmax(score),score.shape)
        n=len(v['ids']);share=v['area']*100
        label=f'{n} CAR'+('S' if n!=1 else '')+f'  {share:.0f}%'
        small=len(state['views'])>10
        fs=12 if small else 14
        width=int(d.textlength(label,font=font(fs,True)))+16
        x=int(np.clip(px-width/2,5,W-width-5));y=int(py+HEADER-10)
        d.rounded_rectangle([x,y,x+width,y+23],radius=5,fill=(15,24,32),outline=(74,97,105))
        text(d,(x+8,y+4),label,fs,WHITE,True)
    y=HEADER+H
    d.rectangle([0,y,W,OH],fill=BG)
    stats=state['stats'];n=sc.N
    passed=sum(st['full_ahead'] for st in stats);visible=sum(st['car_visible'] for st in stats)
    minpx=min(st['car_px'] for st in stats);maxpx=max(st['car_px'] for st in stats)
    minprefix=min(st['ahead_fraction'] for st in stats)
    summary=f'{len(state["views"])} VIEWS    CARS VISIBLE {visible}/{n}    FULL ROAD AHEAD {passed}/{n}    CAR LENGTH {minpx:.0f}-{maxpx:.0f}px'
    text(d,(20,y+12),summary,17,TEAL if passed==n and visible==n else WARN,True)
    text(d,(20,y+41),state['message'],15,WHITE)
    text(d,(20,y+68),'Mint corridor + end-cap = required road ahead. Orange ring = some required corridor is outside its view.',13,MUTED)
    text(d,(20,y+91),f'Budget: max(2 seconds, braking envelope, 24 units). 25px preferred car; 18px hard floor. Worst corridor retained: {minprefix:.0%}.',12,MUTED)
    # Timeline is physical simulation time; it is not another plot.
    frac=state['t']/(sc.duration*sc.time_factor)
    d.rectangle([0,OH-5,int(W*frac),OH],fill=TEAL)
    return im


def serial_state(sc,st):
    return {'t':st['t'],'view_count':len(st['views']),
            'full_ahead':sum(x['full_ahead'] for x in st['stats']),
            'cars_visible':sum(x['car_visible'] for x in st['stats']),
            'min_car_px':min(x['car_px'] for x in st['stats']),
            'max_car_px':max(x['car_px'] for x in st['stats']),
            'min_ahead_fraction':min(x['ahead_fraction'] for x in st['stats']),
            'views':[{'players':[i+1 for i in v['ids']],'area':round(v['area'],6),'scale':round(v['cam']['s'],6),
                      'translation':v['cam']['t'].round(5).tolist(),'fit_region':v['kind']} for v in st['views']],
            'cars':st['stats'],
            'nodes':[{'key':n.key,'u':round(n.u,5),'fit_scale':round(n.fit,5),'level_compatible':n.layer_ok,'region':n.kind} for n in st['nodes'] if n.children]}


def run(index,out,preview=False):
    out=Path(out);(out/'media').mkdir(exist_ok=True,parents=True);(out/'traces').mkdir(exist_ok=True,parents=True)
    sc=Scenario(index);eng=Engine(sc)
    steps=int(sc.duration*FPS)+1
    dt=sc.time_factor/FPS
    stem=f'0{index}-'+{1:'convergence',2:'interrupted-merge',3:'sixteen-view-stress',4:'hairpin-bridge'}[index]
    traces=[];start=time.time()
    if not preview:
        proc=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-vcodec','rawvideo',
            '-pix_fmt','rgb24','-s',f'{W}x{OH}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-crf','21','-preset','veryfast',
            '-pix_fmt','yuv420p','-movflags','+faststart',str(out/'media'/f'{stem}.mp4')],stdin=subprocess.PIPE)
    snapshots=[]
    for f in range(steps):
        st=eng.step(f*dt,dt);traces.append(serial_state(sc,st))
        draw_frame=not preview or f in {0,int(steps*.25),int(steps*.5),int(steps*.75),steps-1}
        if draw_frame:
            im=render(sc,st)
            if not preview:proc.stdin.write(np.asarray(im).tobytes())
            if f in {0,int(steps*.25),int(steps*.5),int(steps*.75),steps-1}:
                fname=f'{stem}-frame-{f:04d}.png';im.save(out/'media'/fname);snapshots.append(fname)
        if f%100==0:print(f'Scenario {index}: {f}/{steps}, {len(st["views"])} views, ahead {traces[-1]["full_ahead"]}/{sc.N}, elapsed {time.time()-start:.1f}s',flush=True)
    if not preview:
        proc.stdin.close();proc.wait()
        if proc.returncode:raise RuntimeError('ffmpeg encoding failed')
    metrics={'scenario':index,'title':sc.names[index],'players':sc.N,'physical_duration':sc.duration*sc.time_factor,
             'playback_duration':sc.duration,'fps':FPS,'frame_count':len(traces),
             'view_count_min':min(x['view_count'] for x in traces),'view_count_max':max(x['view_count'] for x in traces),
             'all_cars_visible_frame_fraction':sum(x['cars_visible']==sc.N for x in traces)/len(traces),
             'full_corridor_player_frame_fraction':sum(x['full_ahead'] for x in traces)/(len(traces)*sc.N),
             'minimum_car_px':min(x['min_car_px'] for x in traces),
             'final_view_count':traces[-1]['view_count'],'final_full_ahead':traces[-1]['full_ahead'],
             'max_power_area_residual_fraction':eng.area_error,'events':eng.events,'snapshots':snapshots}
    (out/'traces'/f'{stem}.json').write_text(json.dumps({'parameters':dataclasses.asdict(B),'metrics':metrics,'frames':traces},separators=(',',':')))
    (out/'traces'/f'{stem}-summary.json').write_text(json.dumps(metrics,indent=2))
    print(json.dumps({k:v for k,v in metrics.items() if k not in ['events','snapshots']},indent=2),flush=True)
    return metrics

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='./camera-lab');p.add_argument('--scenario',type=int);p.add_argument('--preview',action='store_true')
    args=p.parse_args()
    for i in ([args.scenario] if args.scenario else [1,2,3,4]):run(i,args.out,args.preview)
