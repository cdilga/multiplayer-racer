from pathlib import Path
import json
from playwright.sync_api import sync_playwright
root=Path(__file__).parents[1]
errors=[];checks=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1200,'height':1040},device_scale_factor=1)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content((root.parent/'camera-lab-review.html').read_text(),wait_until='load')
    for i in range(4):
        page.locator('#tabs button').nth(i).click()
        page.wait_for_function('document.getElementById("video").readyState >= 1')
        markers=page.locator('#markers button')
        failure=page.get_by_role('button',name='Inspect failure',exact=True)
        if failure.count():failure.click()
        else:page.get_by_role('button',name='Merged',exact=True).click()
        page.wait_for_timeout(400)
        data=page.evaluate('''() => {let v=document.getElementById('video');return {time:v.currentTime,duration:v.duration,ready:v.readyState,error:v.error?String(v.error.code):null,status:document.querySelector('.status').innerText}}''')
        assert data['error'] is None
        assert data['ready']>=2
        checks.append({'scenario':i+1,**data})
        if i in (0,3):page.screenshot(path=str(root/'media'/f'review-browser-{i+1}.png'),full_page=False)
    page.set_viewport_size({'width':390,'height':844})
    page.locator('#tabs button').nth(0).click()
    page.wait_for_timeout(200)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    page.screenshot(path=str(root/'media'/'review-browser-mobile.png'))
    browser.close()
assert not errors,errors
(root/'traces'/'browser-checks.json').write_text(json.dumps({'checks':checks,'errors':errors,'mobile_horizontal_overflow':False},indent=2))
print(json.dumps(checks,indent=2))
