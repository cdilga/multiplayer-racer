"""Package existing deterministic recordings into an offline, frame-steppable review."""
from pathlib import Path
import base64,json,html,zipfile

ROOT=Path(__file__).parents[1]
NAMES=['01-convergence','02-interrupted-merge','03-sixteen-view-stress','04-hairpin-bridge']
EXPLAIN=[
 'Three four-car packs converge while four outsiders retain their own views. The final pack receives 64% of the canvas; each outsider gets 9%. Both complete recorded visibility checks pass in this fixture.',
 'Two four-car packs begin merging. A route choice changes their predicted corridor mid-transition, so the tween reverses. They later reunite. The event markers are derived from the simulation, not edited into the movie.',
 'A sixteen-car convoy stretches and accelerates, reaching sixteen independent views. This is a deliberate failure test: the 18-pixel car-size floor is retained rather than making the vehicles microscopic. Some transitions also clip cars. The replay is accelerated 3.33 times.',
 'Twelve drivers on a hairpin and four on an upper-level road. The mint prediction follows the bend; the white dashed ray is a straight-heading comparison. The split has a short, real clipping failure. The bridge separation is a conservative semantic rule, not a 3-D occlusion calculation.'
]

cases=[]
for i,name in enumerate(NAMES):
    full=json.loads((ROOT/'traces'/f'{name}.json').read_text())
    m=full['metrics'];fs=full['frames'];ratio=m['physical_duration']/m['playback_duration']
    compact=[{'t':f['t'],'views':f['view_count'],'cars':f['cars_visible'],'ahead':f['full_ahead'],
              'minpx':f['min_car_px'],'maxpx':f['max_car_px'],'worst':f['min_ahead_fraction']} for f in fs]
    markers=[{'label':'Start','frame':0}]
    # Real state changes, with extra emphasis on reversal and recovery.
    ev=m['events']
    for typ,label,choose_last in [('merge_start','Merge begins',False),('reverse_tween','Tween reverses',False),
                                  ('split_start','Split begins',False),('merge_complete','Merged',True)]:
        es=[e for e in ev if e['type']==typ]
        if es:
            e=es[-1] if choose_last else es[0]
            idx=min(range(len(fs)),key=lambda k:abs(fs[k]['t']-e['t']))
            markers.append({'label':label,'frame':idx})
    bad=min(range(len(fs)),key=lambda k:(fs[k]['cars_visible'],fs[k]['full_ahead'],fs[k]['min_ahead_fraction']))
    if fs[bad]['cars_visible']<m['players'] or fs[bad]['full_ahead']<m['players']:
        markers.append({'label':'Inspect failure','frame':bad})
    if i==2:
        j=next(k for k,f in enumerate(fs) if f['view_count']==16)
        markers.append({'label':'16 views','frame':j})
    markers.append({'label':'End','frame':len(fs)-1})
    poster=m['snapshots'][2]
    cases.append({'title':m['title'],'description':EXPLAIN[i],'players':m['players'],'fps':m['fps'],
        'ratio':ratio,'frames':compact,'markers':markers,'metrics':m,
        'video':'data:video/mp4;base64,'+base64.b64encode((ROOT/'media'/f'{name}.mp4').read_bytes()).decode(),
        'poster':'data:image/png;base64,'+base64.b64encode((ROOT/'media'/poster).read_bytes()).decode()})

payload=json.dumps(cases,separators=(',',':'))
page=r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Camera Lab — four route-aware split-screen tests</title>
<style>
:root{color-scheme:dark;--bg:#0e141d;--panel:#17222c;--muted:#a4b9c0;--line:#344650;--mint:#4fe1b4;--warn:#ff735e}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#ecf3ef;font:16px/1.5 system-ui,sans-serif}
main{max-width:1180px;margin:auto;padding:26px 20px 56px}h1{font-size:clamp(26px,5vw,40px);line-height:1.12;margin:8px 0 12px}h2{font-size:21px;line-height:1.25}
p{max-width:90ch}small,.muted{color:var(--muted)}.kicker{color:var(--mint);font-weight:700;font-size:13px;letter-spacing:.12em}
nav{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:24px 0 16px}
button,select{background:var(--panel);color:inherit;border:1px solid var(--line);padding:10px 14px;border-radius:8px;font:inherit;cursor:pointer}
nav button{text-align:left;min-height:78px}nav strong{display:block;color:var(--mint)}button:hover,button.active{border-color:var(--mint);background:#1c343a}
video{width:100%;height:auto;display:block;border-radius:10px;background:#000;border:1px solid var(--line)}
.controls,.markers,.status{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin:12px 0}.status{padding:12px 14px;background:var(--panel);border-radius:8px;font-variant-numeric:tabular-nums;justify-content:space-between}
input[type=range]{width:100%;accent-color:var(--mint);margin:6px 0}.good{color:var(--mint)}.bad{color:var(--warn)}
.markers button{font-size:14px;padding:7px 11px}.note{padding:14px 18px;border-left:3px solid var(--mint);background:var(--panel)}
details{margin:24px 0;border:1px solid var(--line);padding:14px 18px;border-radius:9px}summary{cursor:pointer;font-weight:650}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:9px 7px;border-bottom:1px solid var(--line);text-align:left}code{font-size:.95em}
@media(max-width:680px){main{padding:18px 12px 36px}nav{grid-template-columns:repeat(2,1fr)}.controls button{padding:8px 10px}.status{font-size:14px}table{font-size:12px}}
</style><main>
<div class="kicker">JOYSTICK JAMMERS / ALGORITHM LAB / BASELINE A</div>
<h1>Keep the road ahead in view.<br>Then decide who can share a camera.</h1>
<p class="muted">Four deterministic, code-rendered 2-D tests. Actual power-region geometry, camera fitting, merge decisions and visibility diagnostics; scripted vehicle routes. These are not recordings from the game.</p>
<nav id="tabs"></nav>
<h2 id="title"></h2><p id="description"></p>
<video id="video" controls playsinline muted loop preload="metadata"></video>
<div class="controls"><button id="toggle">Play</button><button id="back">← One frame</button><button id="next">One frame →</button><label>Speed <select id="speed"><option value=".25">0.25×</option><option value=".5">0.5×</option><option selected value="1">1×</option><option value="1.5">1.5×</option></select></label><span class="muted" id="clock"></span></div>
<input id="scrub" type="range" min="0" max="400" step="1" value="0" aria-label="Recorded frame">
<div class="markers" id="markers"></div>
<div class="status"><span id="views"></span><span id="cars"></span><span id="ahead"></span><span id="scale"></span></div>
<p class="note"><strong>Reading the animation:</strong> mint strips are the required future road corridor, including its width and terminal end-cap. Orange rings indicate a clipped corridor. The counters measure the actual player-owned presentation mask—not merely the camera's rectangular bounds. Looping back to the start is a replay reset, not a tested camera transition.</p>
<details open><summary>What this run actually implements</summary>
<p>Population-weighted power-cell areas; persistent per-player atoms whose unions can share one projection; common orientation and a common preferred world scale; LP framing of cars plus road-following footprints; merge/split hysteresis; reversible camera convergence; seam-ink fading only when projections nearly agree. World images are not crossfaded.</p>
<table><tbody>
<tr><td>Area allocation</td><td>80% per player + 20% per independently visible group, adjusted gradually after grouping changes.</td></tr>
<tr><td>Road ahead</td><td>max(24 units, 2 × current speed, 0.35 × speed + speed² / 14 + 8). Sampled along the chosen route, with road width.</td></tr>
<tr><td>Scale</td><td>25-pixel preferred car length on the 1080 × 560 toy canvas; 18-pixel hard floor. These are test parameters, not validated TV ergonomics.</td></tr>
<tr><td>Merge timing</td><td>0.45-second qualification hold; 1.6-second projection transition. Reverse from the current transition state when the fit fails.</td></tr>
<tr><td>Framing geometry</td><td>Convex cells: linear-program fit. Compound masks: a conservative contained kernel or verified inscribed rectangle. Never a convex hull that includes another player's region.</td></tr>
<tr><td>Purposeful limits</td><td>Fixed site anchors and predeclared candidate merge trees. No full layout optimiser, free-form grouping search, physics, 3-D occlusion, controller input or production asset integration.</td></tr>
</tbody></table>
<p><strong>Visibility means containment here.</strong> The audit samples car corners and road-width cross-sections against an inset mask. It does not prove visibility through obstacles, avoid all overlapping cars/HUD annotations, or test every continuous instant between recorded samples. The movies are encoded at 20 fps; this is not a game-performance benchmark.</p>
</details>
<details><summary>Observed results and checks</summary><div id="results"></div><p>Additional numeric tests cover 1, 2, 5, 16 and 32 power sites, including target areas, coverage and overlaps. The 32-site result is a partition test—not a 32-camera gameplay or performance demonstration.</p></details>
<details><summary>Review focus</summary><p>Start with the first convergence: should the twelve-player pack use its large region differently while preserving the common scale? Then inspect the interrupted merge. Use “Inspect failure” on the convoy and hairpin tests: final-view feasibility does not guarantee a safe path between views. In particular, persistent screen ownership cannot remain rigid when a later split needs a different divider direction.</p><p>Playback controls do not change the algorithm. Constants, routes and candidate trees are in the accompanying Python source for the next controlled run.</p></details>
<small>Generated locally from the included source and per-frame traces. No remote scripts, fonts, analytics or network requests.</small>
</main><script>
const cases=PAYLOAD;let active=0;const $=s=>document.getElementById(s);const v=$('video');
const tabs=['12 + 4 converge','Interrupted merge','16-view stress','Hairpin + bridge'];
cases.forEach((c,i)=>{const b=document.createElement('button');b.innerHTML='<strong>0'+(i+1)+'</strong>'+tabs[i];b.onclick=()=>selectCase(i);$('tabs').appendChild(b)});
function currentFrame(){return Math.min(cases[active].frames.length-1,Math.max(0,Math.floor(v.currentTime*cases[active].fps+0.001)))}
function seekFrame(f){const c=cases[active];f=Math.max(0,Math.min(c.frames.length-1,f));v.pause();v.currentTime=f/c.fps;$('scrub').value=f;update()}
function selectCase(i){active=i;const c=cases[i];v.pause();v.src=c.video;v.poster=c.poster;v.playbackRate=Number($('speed').value);$('title').textContent='0'+(i+1)+' / '+c.title;$('description').textContent=c.description;$('scrub').max=c.frames.length-1;$('scrub').value=0;[...$('tabs').children].forEach((b,j)=>b.classList.toggle('active',i===j));$('markers').replaceChildren();c.markers.forEach(m=>{const b=document.createElement('button');b.textContent=m.label;b.onclick=()=>seekFrame(m.frame);$('markers').appendChild(b)});update()}
function update(){const c=cases[active],idx=currentFrame(),f=c.frames[idx];$('scrub').value=idx;$('clock').textContent=f.t.toFixed(2)+'s simulation / frame '+idx;$('views').textContent=f.views+' visible views';$('cars').textContent='Cars: '+f.cars+'/'+c.players;$('cars').className=f.cars===c.players?'good':'bad';$('ahead').textContent='Complete road ahead: '+f.ahead+'/'+c.players;$('ahead').className=f.ahead===c.players?'good':'bad';$('scale').textContent='Car length: '+f.minpx.toFixed(1)+'–'+f.maxpx.toFixed(1)+' px';$('toggle').textContent=v.paused?'Play':'Pause'}
$('toggle').onclick=()=>{if(v.paused)v.play();else v.pause();update()};$('back').onclick=()=>seekFrame(currentFrame()-1);$('next').onclick=()=>seekFrame(currentFrame()+1);$('scrub').oninput=e=>seekFrame(+e.target.value);$('speed').onchange=e=>v.playbackRate=+e.target.value;v.ontimeupdate=update;v.onplay=update;v.onpause=update;v.onseeked=update;
let table='<table><thead><tr><th>Fixture</th><th>View range</th><th>Frames with car clipping</th><th>Frames with corridor clipping</th></tr></thead><tbody>';
cases.forEach((c,i)=>{let cars=c.frames.filter(f=>f.cars<c.players).length;let ahead=c.frames.filter(f=>f.ahead<c.players).length;table+='<tr><td>0'+(i+1)+'</td><td>'+c.metrics.view_count_min+'–'+c.metrics.view_count_max+'</td><td>'+cars+' / '+c.frames.length+'</td><td>'+ahead+' / '+c.frames.length+'</td></tr>'});$('results').innerHTML=table+'</tbody></table>';selectCase(0);
</script></html>'''.replace('PAYLOAD',payload)
(ROOT.parent/'camera-lab-review.html').write_text(page)
params=json.loads((ROOT/'traces'/f'{NAMES[0]}.json').read_text())['parameters']
(ROOT/'parameters.json').write_text(json.dumps(params,indent=2))
readme='''# Route-aware multiplayer camera lab — Baseline A

This is a standalone, deterministic 2-D algorithm exercise, not the Joystick Jammers game. No repository files were changed.

## Open the results
Open `camera-lab-review.html` (provided separately) for four embedded videos, slow motion, frame stepping, and markers derived from actual solver events. MP4s are also in `media`. Per-frame metrics and projected view ownership are in `traces`.

## Reproduce
Python 3.10+; `pip install numpy scipy pillow shapely opencv-python`; install the `ffmpeg` executable. Run:

    python source/camera_lab.py --out ./rerun
    python source/test_camera_lab.py ./rerun

The renderer uses DejaVu Sans at the standard Linux path. Set `FONT` and `BOLD` in the source to locally installed equivalents on other operating systems; font files are not distributed.

Change the `Budget` dataclass to try constants, and the `Scenario` fixtures to try trajectories. The animation duration and physical time differ for scenario 3; this is stated on-screen. Scripted paths supply reproducible positions and speeds; they are not a rigid-body simulation.

## Candidate representation
All players retain an internal power-diagram allocation unit. The independently visible groups receive `0.8 * group_players / total_players + 0.2 / group_count` screen share. The targets are divided across their atoms; power weights are solved using damped Newton updates, not set directly equal to population. Group changes introduce area targets gradually. Equal-projection atoms render as a single group mask, so completed merges preserve/add ownership rather than recreate the partition.

Preferred car length is 25 pixels on a 1080 x 560 game canvas; the floor is 18. Camera fitting includes road width, the actual upcoming route and a toy stopping envelope. If a leaf cannot accommodate everything at the floor, the failure is left visible. The sample checks do not hide failure by moving the green endpoint inward.

A convex region allows a three-variable linear programme in scale and screen translation. Non-convex unions use a contained kernel or a verified inscribed rectangle; this conservative approximation can reject usable fits. A union's convex hull is never substituted as though neighbouring players' pixels were available.

## Important boundaries
Site anchors are fixed and merge candidates use a predeclared hierarchy. Full site-motion optimisation, arbitrary graph grouping, collision physics, controls, assets, 3-D occlusion and real TV ergonomics are not implemented. This deliberately isolates the camera/mask transition experiment. An endpoint-fit test and projection tween are NOT a guarantee of safe intermediate states. The stress and hairpin traces contain actual clipping failures. Those failures do not prove that a better algorithm or layout would fail.

The bridge fixture uses explicit level metadata as a conservative merge veto; it does not calculate visual occlusion. Visibility counters test geometric containment at sampled instants, not visibility through obstacles, occlusion by cars, label overlaps or player comprehension. Encoding at 20 fps is not a runtime-performance claim.

## Expected findings in this recording
Scenario 1: 7 -> 6 -> 5 views; final 12-player region about 64%, each outsider about 9%; no sampled car/corridor clipping.
Scenario 2: merge starts at 5.75s, reverses at 6.65s after a fork decision, and later completes at 15.60s; no sampled clipping.
Scenario 3: 1 -> 16 views as a convoy stretches and accelerates; 30/361 frames have some car clipping and 178/361 have some corridor clipping. Some frames precede the full sixteen-view state: not all failure is a small-cell problem.
Scenario 4: 3 -> 2 -> 3 views; re-splitting produces car clipping in 5/361 frames and corridor clipping in 10/361. A rotating/reallocated child mask and a transition-path feasibility check are needed; endpoint fit alone is insufficient.

## Sources for mathematical/software building blocks
Capacity-constrained power diagrams: https://inria.hal.science/hal-01401949
SciPy HiGHS linear programming: https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html
Unity camera lookahead documentation (why prediction needs smoothing): https://docs.unity3d.com/Packages/com.unity.cinemachine@3.1/manual/CinemachinePositionComposer.html

The numerical thresholds and UX policy are toy experiment settings, not published ergonomic recommendations.
'''
(ROOT/'README.md').write_text(readme)
# Keep the bundle small: MP4s rather than the much larger inline GIF previews.
with zipfile.ZipFile(ROOT.parent/'camera-lab-source-and-replays.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in [ROOT/'README.md',ROOT/'parameters.json']+list((ROOT/'source').glob('*.py'))+list((ROOT/'traces').glob('*.json'))+list((ROOT/'media').glob('*.mp4')):
        z.write(path,Path('camera-lab')/path.relative_to(ROOT))
print('Created',ROOT.parent/'camera-lab-review.html')
print('Created',ROOT.parent/'camera-lab-source-and-replays.zip')
