# Route-aware multiplayer camera lab — Baseline A

This is a standalone, deterministic 2-D algorithm exercise, not the Joystick Jammers game. No repository files were changed.

## Open the results
Open `camera-lab-review.html` (provided separately) for four embedded videos, slow motion, frame stepping, and markers derived from actual solver events. MP4s are also in `media`. Per-frame metrics and projected view ownership are in `traces`.

## Reproduce
Python 3.10+; `pip install numpy scipy pillow shapely opencv-python`; install the `ffmpeg` executable. Run:

    python source/camera_lab.py --out ./rerun
    python source/test_camera_lab.py ./rerun

The renderer uses DejaVu Sans at the standard Linux path. Set `FONT` and `BOLD` in the source to locally installed equivalents on other operating systems; font files are not distributed.

Change the `Budget` dataclass to try constants, and the `Scenario` fixtures to try trajectories. The animation duration and physical time differ for scenario 3; this is stated on-screen. Scripted paths supply reproducible positions and speeds; they are not a rigid-body simulation.

## Candidate representation
All players retain an internal power-diagram allocation unit. The independently visible groups receive `0.8 * group_players / total_players + 0.2 / group_count` screen share. The targets are divided across their atoms; power weights are solved using damped Newton updates, not set directly equal to population. Group changes introduce area targets gradually. Equal-projection atoms render as a single group mask, so completed merges preserve/add ownership rather than recreate the partition.

Preferred car length is 25 pixels on a 1080 x 560 game canvas; the floor is 18. Camera fitting includes road width, the actual upcoming route and a toy stopping envelope. If a leaf cannot accommodate everything at the floor, the failure is left visible. The sample checks do not hide failure by moving the green endpoint inward.

A convex region allows a three-variable linear programme in scale and screen translation. Non-convex unions use a contained kernel or a verified inscribed rectangle; this conservative approximation can reject usable fits. A union's convex hull is never substituted as though neighbouring players' pixels were available.

## Important boundaries
Site anchors are fixed and merge candidates use a predeclared hierarchy. Full site-motion optimisation, arbitrary graph grouping, collision physics, controls, assets, 3-D occlusion and real TV ergonomics are not implemented. This deliberately isolates the camera/mask transition experiment. An endpoint-fit test and projection tween are NOT a guarantee of safe intermediate states. The stress and hairpin traces contain actual clipping failures. Those failures do not prove that a better algorithm or layout would fail.

The bridge fixture uses explicit level metadata as a conservative merge veto; it does not calculate visual occlusion. Visibility counters test geometric containment at sampled instants, not visibility through obstacles, occlusion by cars, label overlaps or player comprehension. Encoding at 20 fps is not a runtime-performance claim.

## Expected findings in this recording
Scenario 1: 7 -> 6 -> 5 views; final 12-player region about 64%, each outsider about 9%; no sampled car/corridor clipping.
Scenario 2: merge starts at 5.75s, reverses at 6.65s after a fork decision, and later completes at 15.60s; no sampled clipping.
Scenario 3: 1 -> 16 views as a convoy stretches and accelerates; 30/361 frames have some car clipping and 178/361 have some corridor clipping. Some frames precede the full sixteen-view state: not all failure is a small-cell problem.
Scenario 4: 3 -> 2 -> 3 views; re-splitting produces car clipping in 5/361 frames and corridor clipping in 10/361. A rotating/reallocated child mask and a transition-path feasibility check are needed; endpoint fit alone is insufficient.

## Sources for mathematical/software building blocks
Capacity-constrained power diagrams: https://inria.hal.science/hal-01401949
SciPy HiGHS linear programming: https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html
Unity camera lookahead documentation (why prediction needs smoothing): https://docs.unity3d.com/Packages/com.unity.cinemachine@3.1/manual/CinemachinePositionComposer.html

The numerical thresholds and UX policy are toy experiment settings, not published ergonomic recommendations.
